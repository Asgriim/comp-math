//
// Created by asgrim on 10.04.23.
//

#ifndef COMP_MATH3_METHODS_H
#define COMP_MATH3_METHODS_H
#include "Integral.h"
    double simpsonMethod(double left, double right, int n, Integral & integral, double epsilon);
#endif //COMP_MATH3_METHODS_H
