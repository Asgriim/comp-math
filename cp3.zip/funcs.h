//
// Created by asgrim on 10.04.23.
//

#ifndef COMP_MATH3_FUNCS_H
#define COMP_MATH3_FUNCS_H
double sinFunc(double x);
double gipebol(double x);
double cube(double x);
#endif //COMP_MATH3_FUNCS_H
